<?php

namespace App\Http\Controllers\Api\Wp;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

use App\Models\StaticElecticResidential;
use App\Models\StaticGasResidential;
use App\Models\StaticElectricProfessional;
use App\Models\StaticGasProfessional;
use App\Models\PostalcodeElectricity;
use App\Models\PostalcodeGas;
use App\Models\StaticPackResidential;
use App\Models\StaticPackProfessional;
use App\Models\Netcostes;
use App\Models\Netcostgs;
use App\Models\TaxElectricity;
use App\Models\TaxGas;

use App\Models\DynamicElectricProfessional;
use App\Models\DynamicGasProfessional;
use App\Models\DynamicElectricResidential;
use App\Models\DynamicGasResidential;

use App\Models\Discount;
use App\Models\Supplier;

class wpController extends Controller
{
    public function supplier_details(Request $request){

    	$pack=StaticPackResidential::where('check_elec',$request->supplier)->pluck('pack_id'); 

    	$electricity=StaticElecticResidential::where('supplier',$request->supplier)->pluck('product_id');

    	$product['electricity'] = $electricity;
    	$product['pack'] = $pack;
    	return $product;
    	exit();

    	$packs= array();
    	$electricity= array();

    	foreach ($pack as $key => $value) {
    	  		$packs[]=utf8_encode($value);
    	  	} 
    	foreach ($electricity as $key => $value) {
    	  		$electricity[]=utf8_encode($value);
    	  	} 	


   		$pdoduct['electricity'] = $electricity;
        $pdoduct['pack'] = $packs;    
        return $pdoduct;
    }
}
